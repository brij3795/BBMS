import { Component, OnInit } from '@angular/core';
import { UserLogin } from '../model/userlogin';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { User } from '../model/user';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  userlogin: User;

  constructor(private service: ServiceService, private router: Router) {
    this.userlogin = new User();
  }

  ngOnInit() {

    
  }
  
  getLogin() {

    this.service.verifyUser(this.userlogin).subscribe(res => {
      this.userlogin = res;
      if (this.userlogin != null) {
        sessionStorage.setItem('useremail', this.userlogin.userEmail);
        this.router.navigate(['viewuser'])
        console.log(this.userlogin)
      }
    }
    );


  };
}
