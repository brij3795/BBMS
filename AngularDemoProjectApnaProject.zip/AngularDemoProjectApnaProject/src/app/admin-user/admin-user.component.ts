import { Component, OnInit } from '@angular/core';
import { User } from '../Model/user';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-user',
  templateUrl: './admin-user.component.html',
  styleUrls: ['./admin-user.component.css']
})
export class AdminUserComponent implements OnInit {


  userArr:User[]=[];
  userArray:User[]=[];
  user:User[];

  aPulse:number=0;
  aMinus:number=0;
  abPulse:number=0;
  abMinus:number=0;
  bPulse:number=0;
  bMinus:number=0;
  oPulse:number=0;
  oMinus:number=0;
  count:number=0;
  constructor(private service:ServiceService,private router:Router) { }

  ngOnInit() {
    this.getUser();
    console.log(this.userArr);
    this.service.getUser().subscribe(res=>{
      this.userArr=res;
      JSON.stringify(this.userArr);

      this.userArr.forEach(element => {
        console.log(this.userArray)
        if(element.userBloodGroup==="AB+")
        {
          this.abPulse++;
        }
        else if(element.userBloodGroup==="AB-")
        {
          this.abMinus++;
        }
        else if(element.userBloodGroup==="A-")
        {
          this.aMinus++;
        }
        else if(element.userBloodGroup==="A+")
        {
          this.aPulse++;
        }

        else if(element.userBloodGroup==="O+")
        {
          this.oPulse++;
        }
        else if(element.userBloodGroup==="O-")
        {
          this.oMinus++;
        }
        else if(element.userBloodGroup==="B-")
        {
          this.bMinus++;
        }

        else if(element.userBloodGroup==="B+")
        {
          this.bPulse++;
        }
      })
    })
  }



getUser(){
  console.log(this.userArr);
  this.service.getUser().subscribe(res=>{
    this.userArr=res;
    JSON.stringify(this.userArr);
    return this.userArr;
  });
}
}
