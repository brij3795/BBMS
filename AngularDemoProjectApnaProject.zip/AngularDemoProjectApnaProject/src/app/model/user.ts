export class User {
 id: number;
 userFirstName: any;
 userLastName: any;
 userContact: any;
 userEmail: any;
 userBloodGroup: any;
 uDOB:Date;
 userAddress:any;
 userGender:any;
 userPassword:any;

}
