export class User {
 id: number;
 userFirstName: any;
 userLastName: any;
 userContact: any;
 userEmail: any;
 userBloodGroup: any;
 uDOB:any;
 userAddress:any;
 userGender:any;

}
