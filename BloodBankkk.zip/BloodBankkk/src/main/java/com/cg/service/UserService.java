package com.cg.service;

import java.util.List;

import com.cg.entity.Patient;
import com.cg.entity.User;

public interface UserService {
	
	
	public User addUser(User u);
	
	public List<User> getUser();
	
	public User selectUser(String email);
	
	public List<User> matchUser(String bloodgroup,String location);
	
	public List<Patient> matchedPatientToUser(int userId);
	
	public User addPatientToList(Patient p,int userId);
	
	public User getUserEmail(String email);
	
	public User verifyUser(User user);

}
