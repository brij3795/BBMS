package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Patient;
import com.cg.entity.User;
import com.cg.repo.PatientRepo;
import com.cg.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;
	
	@Autowired
	PatientRepo patientRepo;

	@Override
	public User addUser(User u) {

		return userRepo.save(u);
	}

	@Override
	public List<User> getUser() {
		return (List<User>) userRepo.findAll();
	}

	public List<User> matchUser(String bloodgroup, String location) {

		List<User> users = userRepo.findByUserBloodGroupAndUserAddress(bloodgroup, location);

		return users;

	}

	@Override
	public User selectUser(String email) {

		User user = userRepo.findByUserEmail(email);
		
		userRepo.delete(user);
		

		return user;
	}
	@Override
	public List<Patient> matchedPatientToUser(int userId) {
		User user = userRepo.findById(userId).get();
		List<Patient> patients = user.getMatchedpatients();

		return patients;

	}
	@Override
	public User addPatientToList(Patient p,int userId) {
		User user = userRepo.findById(userId).get();
		List<Patient> patientList = user.getMatchedpatients();
		patientList.add(p);
		userRepo.save(user);
		
		
		return user;
	}

	@Override
	public User getUserEmail(String email) {
		return userRepo.findByUserEmail(email);
	}

	@Override
	public User verifyUser(User user) {
		User userFromQuery = userRepo.findByUserEmail(user.getUserEmail());
		
		if(userFromQuery !=  null) {
			if(userFromQuery.getUserPassword().equals(user.getUserPassword())) {
				return user;
			}
		}
		return null;
	}
}
