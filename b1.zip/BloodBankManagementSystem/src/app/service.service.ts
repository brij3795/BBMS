import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
baseUrl="http://localhost:8888";
  constructor(private http:HttpClient) { }
}
