export class Patient {
    patientname: string;
    contact: string;
    BloodGroup:string;
    HospitalLoc:String;
}