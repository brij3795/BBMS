import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patientdetails',
  templateUrl: './patientdetails.component.html',
  styleUrls: ['./patientdetails.component.css']
})
export class PatientdetailsComponent implements OnInit {

  patientdetailsArrPatient[]=[];

  patientdetails: PatientDetails;
  constructor() { 
    this.patientdetails = new PatientDetails();
  }


  ngOnInit() {
  }
get() {
  sessionStorage.setItem('', );
  sessionStorage.setItem('', );
  sessionStorage.setItem('', );
  sessionStorage.setItem('', );
  console.log(sessionStorage);
}
}