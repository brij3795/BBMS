export class Patient {
    id: number;
    patientName: string;
    patientContact: string;
    patientBloodGroup: string;
    patientHospitalLoc: string;
}
