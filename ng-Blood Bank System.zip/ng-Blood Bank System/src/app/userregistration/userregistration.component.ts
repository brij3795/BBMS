import { Component, OnInit, Input } from "@angular/core";
import { User } from "../model/user";
import { ServiceService } from "../service.service";
import { Router } from '@angular/router';


@Component({
  selector: "app-userregistration",
  templateUrl: "./userregistration.component.html",
  styleUrls: ["./userregistration.component.css"]
})
export class UserregistrationComponent implements OnInit {

  @Input() email;
  @Input() contact;
  userArr: User[] = [];
  user: User;
  allEmailId = [];
  emailCheck: boolean;
  userName: any;
  userContact: any;
  userBloodGroup: any;
  userEmail: any;




  constructor(private service: ServiceService, private router: Router) {
    this.user = new User() ;
    this.userName = this.user.userName;
    this.userBloodGroup = this.user.userBloodGroup;
    this.userContact = this.user.userContact;
    this.userEmail = this.user.userEmail;

  }

  ngOnInit() {

  }

  addUser() {
    this.service.addUser(this.user).subscribe(data => {
      console.log(data);
    });
  }

  getUsers() {
    this.service.getUser().subscribe(res => {
      this.userArr = res;
      if(this.userArr.length===0){
        this.addUser();
        this.router.navigate(['/admin']);

      }
      for (const u of this.userArr) {
        if (this.user.userEmail !== u.userEmail || u.userContact === '') {
          this.emailCheck = true;
        }
        else {
          this.emailCheck = false;
          alert('user id exists');
          break;
        }

      }
      if (this.emailCheck) {
        this.addUser();
        this.router.navigate(['/admin']);
      }

    });
  }

  Validation() {
    if (this.user.userEmail.invalid && (this.user.userEmail.dirty || this.user.userEmail.touched)) {
     alert('email is not valid');
    }
    if (this.user.userContact.invalid && (this.user.userContact.dirty || this.user.userContact.touched)) {
      alert('Contact is not valid');
     }
    else {
      this.getUsers();
    }
  }
}
