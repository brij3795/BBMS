package com.cg.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;


import com.cg.entity.User;

public interface UserRepo extends CrudRepository<User, Integer> {
	
	public List<User> findByUserBloodGroupAndUserAddress(String bloodgroup,String location);

	public User findByUserEmail(String userEmail);

}
