package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.User;

import com.cg.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepo userRepo;

	@Override
	public User addUser(User u) {

		return userRepo.save(u);
	}

	@Override
	public List<User> getUser() {
		return (List<User>) userRepo.findAll();
	}

	public List<User> matchUser(String bloodgroup, String location) {

		List<User> users = userRepo.findByUserBloodGroupAndUserAddress(bloodgroup, location);

		return users;

	}

	@Override
	public User selectUser(int id) {

		User user = userRepo.findById(id).get();
		userRepo.delete(user);

		return user;
	}

	@Override
	public User verifyUser(User user) {
		User userFromQuery = userRepo.findByUserEmail(user.getUserEmail());

		if (userFromQuery != null) {
			if (userFromQuery.getUserPassword().equals(user.getUserPassword())) {
				return user;
			}
		}

		return null;
	}

	@Override
	public User getUserByEmail(String email) {
		return userRepo.findByUserEmail(email);
	}

}
