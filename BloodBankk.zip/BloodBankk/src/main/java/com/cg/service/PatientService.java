package com.cg.service;

import java.util.List;


import com.cg.entity.Patient;

public interface PatientService {
	
	public Patient addPatient(Patient p);
	
	public List<Patient> getPatientList();
	
	public String deletePatients(int id);

	Patient updatePatient(int id, Patient p);

	Patient getPatientById(int id);

}
