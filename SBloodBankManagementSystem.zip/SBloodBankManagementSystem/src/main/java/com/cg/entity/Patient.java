package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patient_infos")
public class Patient {
	
	@Id 
	@GeneratedValue
	private int id;
	
	
	private String firstName;
	
	private String lastName;
	
	private String pDOB;
	
	private String patientGender;
	
	private String patientEmail;
	
	private String patientBloodGroup;
	

	private String patientContact;
	
	
	
	private String patientHospitalLoc;



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getpDOB() {
		return pDOB;
	}



	public void setpDOB(String pDOB) {
		this.pDOB = pDOB;
	}



	public String getPatientGender() {
		return patientGender;
	}



	public void setPatientGender(String patientGender) {
		this.patientGender = patientGender;
	}



	public String getPatientEmail() {
		return patientEmail;
	}



	public void setPatientEmail(String patientEmail) {
		this.patientEmail = patientEmail;
	}



	public String getPatientBloodGroup() {
		return patientBloodGroup;
	}



	public void setPatientBloodGroup(String patientBloodGroup) {
		this.patientBloodGroup = patientBloodGroup;
	}



	public String getPatientContact() {
		return patientContact;
	}



	public void setPatientContact(String patientContact) {
		this.patientContact = patientContact;
	}



	public String getPatientHospitalLoc() {
		return patientHospitalLoc;
	}



	public void setPatientHospitalLoc(String patientHospitalLoc) {
		this.patientHospitalLoc = patientHospitalLoc;
	}



	
	
	
	

}
