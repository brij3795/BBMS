package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.entity.Patient;
import com.cg.repo.PatientRepo;

@Service
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	PatientRepo patientRepo;

	@Override
	public Patient addPatient(Patient p) {
		return patientRepo.save(p);
	}

	@Override
	public List<Patient> getPatientList() {
		return  (List<Patient>) patientRepo.findAll();
	}

}
