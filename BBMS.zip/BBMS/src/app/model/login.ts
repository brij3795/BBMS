export class Login {
    userId: string;
    password: string;
}