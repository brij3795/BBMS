package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patient_infos")
public class Patient {
	
	@Id @Column(name="patient_ids")  @GeneratedValue
	private int id;
	
	@Column(length=20)
	private String Patient_name;
	
	@Column(length=5)
	private String Patient_Blood_Group;
	
	@Column(length=20)
	private String Patient_Contact;
	
	
	@Column(length=40)
	private String Patient_Hospital_Loc;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getPatient_name() {
		return Patient_name;
	}


	public void setPatient_name(String patient_name) {
		Patient_name = patient_name;
	}


	public String getPatient_Blood_Group() {
		return Patient_Blood_Group;
	}


	public void setPatient_Blood_Group(String patient_Blood_Group) {
		Patient_Blood_Group = patient_Blood_Group;
	}


	public String getPatient_Contact() {
		return Patient_Contact;
	}


	public void setPatient_Contact(String patient_Contact) {
		Patient_Contact = patient_Contact;
	}


	public String getPatient_Hospital_Loc() {
		return Patient_Hospital_Loc;
	}


	public void setPatient_Hospital_Loc(String patient_Hospital_Loc) {
		Patient_Hospital_Loc = patient_Hospital_Loc;
	}
	
	
	

}
