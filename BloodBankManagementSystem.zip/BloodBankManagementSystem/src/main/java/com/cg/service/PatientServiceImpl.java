package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.entity.Patient;
import com.cg.repo.PatientRepo;

@Service
@Transactional
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	PatientRepo patientRepo;

	@Override
	public Patient addPatient(Patient body) {
		return patientRepo.save(body);
	}

	@Override
	public List<Patient> PatientList() {
		return (List<Patient>) patientRepo.findAll();
	}

}
