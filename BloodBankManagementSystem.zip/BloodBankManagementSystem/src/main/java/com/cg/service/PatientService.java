package com.cg.service;

import java.util.List;


import com.cg.entity.Patient;

public interface PatientService {
	
	public Patient addPatient( Patient body);
	
	public List<Patient> PatientList();

}
