import { Component, OnInit } from '@angular/core';
import { Login } from '../model/login';
import { Router } from '@angular/router';
import { setDefaultService } from 'selenium-webdriver/edge';
import { FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: Login;
  userId: any;
  password: any;
  userControl = new FormControl('', [Validators.required]);
  constructor(private router: Router) { 
    this.login = new Login();
    this.userId = this.login.userId;
    this.password = this.login.password;
  }

  ngOnInit() {
  }

  storeCredentials() {
 if ((this.userId === undefined) || (this.password === undefined)) {
 alert('Username and Password cannot be empty');
 }
else {
 sessionStorage.setItem('userId', this.userId);
sessionStorage.setItem('password', this.password);
sessionStorage.setItem('isLoggedIn', 'true');
console.log(sessionStorage);
this.router.navigate(['/admin']);

  }
}

}
