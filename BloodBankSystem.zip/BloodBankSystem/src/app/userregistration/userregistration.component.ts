import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-userregistration',
  templateUrl: './userregistration.component.html',
  styleUrls: ['./userregistration.component.css']
})
export class UserregistrationComponent implements OnInit {


  userArr: User [] = [];

  user: User  ;
  constructor(private service: ServiceService) {
    this.user = new User() ;
   }

  ngOnInit() {
  }

  addUser(){

    this.service.addUser(this.user).subscribe(
      data =>
      {
        console.log(data);
      }
    );


  }

}
