export class Patient {
    patientName: string;
    patientContact: string;
    patientBloodGroup:string;
    patientHospitalLoc:String;
}