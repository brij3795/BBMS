import { Injectable } from '@angular/core';

import { Patient } from './model/patientdetails';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
baseUrl="http://localhost:8888";
patient = Patient;
  constructor(private http:HttpClient) { }

  addPatient(patient: Patient) {
    return this.http.post<Patient>(this.baseUrl + '/addPatient', patient);
  }
}
