import { Component, OnInit } from '@angular/core';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-patientdetails',
  templateUrl: './patientdetails.component.html',
  styleUrls: ['./patientdetails.component.css']
})
export class PatientdetailsComponent implements OnInit {

  patientdetailsArr:Patient[]=[];

  patient: Patient;
  constructor(private service : ServiceService) { 
    this.patient= new Patient();

  }


  ngOnInit() {
  }
  addPatient() {
    this.service.addPatient(this.patient).subscribe(
      data => {
        console.log(data);
      });
}
}