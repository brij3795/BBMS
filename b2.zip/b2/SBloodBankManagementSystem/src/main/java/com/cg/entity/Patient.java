package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patient_infos")
public class Patient {
	
	@Id 
	@GeneratedValue
	private int id;
	
	
	private String patientName;
	
	
	private String patientBloodGroup;
	

	private String patientContact;
	
	
	
	private String patientHospitalLoc;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getPatientName() {
		return patientName;
	}


	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}


	public String getPatientBloodGroup() {
		return patientBloodGroup;
	}


	public void setPatientBloodGroup(String patientBloodGroup) {
		this.patientBloodGroup = patientBloodGroup;
	}


	public String getPatientContact() {
		return patientContact;
	}


	public void setPatientContact(String patientContact) {
		this.patientContact = patientContact;
	}


	public String getPatientHospitalLoc() {
		return patientHospitalLoc;
	}


	public void setPatientHospitalLoc(String patientHospitalLoc) {
		this.patientHospitalLoc = patientHospitalLoc;
	}


	
	
	

}
