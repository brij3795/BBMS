package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patient_infos")
public class Patient {
	
	@Id @Column(name="patient_ids")  @GeneratedValue
	private int id;
	
	@Column(length=20)
	private String patientName;
	
	@Column(length=5)
	private String patientBloodGroup;
	
	@Column(length=20)
	private String patientContact;
	
	
	@Column(length=40)
	private String patientHospitalLoc;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getPatientName() {
		return patientName;
	}


	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}


	public String getPatientBloodGroup() {
		return patientBloodGroup;
	}


	public void setPatientBloodGroup(String patientBloodGroup) {
		this.patientBloodGroup = patientBloodGroup;
	}


	public String getPatientContact() {
		return patientContact;
	}


	public void setPatientContact(String patientContact) {
		this.patientContact = patientContact;
	}


	public String getPatientHospitalLoc() {
		return patientHospitalLoc;
	}


	public void setPatientHospitalLoc(String patientHospitalLoc) {
		this.patientHospitalLoc = patientHospitalLoc;
	}


	
	
	

}
