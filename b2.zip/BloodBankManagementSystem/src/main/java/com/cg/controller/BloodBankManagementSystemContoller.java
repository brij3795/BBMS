package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.cg.entity.Patient;
import com.cg.service.PatientService;



@Controller
public class BloodBankManagementSystemContoller {
	
	@Autowired
	PatientService patientservice;
	
	
	
	@PostMapping(path="/addPatient", consumes="application/json", produces="application/json")
	public Patient addPatient(Patient p)
	{
		return patientservice.addPatient(p);
	}
	
	@GetMapping(path="/getPatient",produces="application/json")
	public List getPatientList(Patient p)
	{
		return (List) patientservice.getPatientList();
	}
	

}
