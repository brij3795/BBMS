import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';
import { User } from '../model/user';
import { MatPaginator, MatTableDataSource } from '@angular/material';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  patientArr: Patient[] = [];
  patient: Patient;
  userArray: User[] = [];
  userArr: User[] = [];
  user: User;
  patientsData: any = [];
  userData: any = [];
  Aminus: number = 0;
  Aplus: number = 0;
  Bminus: number = 0;
  Bplus: number = 0;
  Ominus: number = 0;
  Oplus: number = 0;
  ABminus: number = 0;
  ABplus: number = 0;
  count: number = 0;
  matcheduserArray: User[] = [];
  
  patientId : any;
  [x: string]: any;
  searchTerm: string;
  displayColumns = [
    'id', 'firstName', 'lastName', 'pDOB', 'patientGender', 'patientEmail',
    'patientContact', 'patientBloodGroup','patientHospitalLoc','ACTIONS'
  ];
  displayColumns1 = [
    'id', 'userFirstName', 'userLastName', 'uDOB', 'userGender', 'userEmail',
    'userContact', 'userBloodGroup','userAddress','ACTIONS'
  ];
  displayColumns2 = [
    'id', 'userFirstName', 'userLastName', 'uDOB', 'userGender', 'userEmail',
    'userContact', 'userBloodGroup','userAddress','ACTIONS'
  ];
  dataSource;
  dataSource1;
  dataSource2;



  //  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private router: Router, private service: ServiceService) {
  
  }

  ngOnInit() {
    
  this.getPatients();
    //this.getUsers();
    this.service.getUser().subscribe(res => {
      this.userArr = res;
      JSON.stringify(this.userArr);
      console.log(this.userArr);
      this.dataSource1 = new MatTableDataSource(this.userArr);
      this.userArr.forEach(element => {
        console.log(this.userArray)
        if (element.userBloodGroup === 'A-') {
          this.Aminus++;
        }
        else if (element.userBloodGroup === 'B+') {
          this.Bplus++;
        }
        else if (element.userBloodGroup === 'A+') {
          this.Aplus++;
        }
        else if (element.userBloodGroup === 'AB+') {
          this.ABplus++;
        }
        else if (element.userBloodGroup === 'AB-') {
          this.ABminus++;
        }
        else if (element.userBloodGroup === 'A+') {
          this.Aplus++;
        }
        else if (element.userBloodGroup === 'B-') {
          this.Bminus++;
        }
        else if (element.userBloodGroup === 'O+') {
          this.Oplus++;
        }
        else if (element.userBloodGroup === 'O-') {
          this.Ominus++;
        }

      });

    });
  }

 

 
  getPatients() {
    console.log(this.patientArr);
    this.service.getPatient().subscribe(res => {
      this.patientArr = (res);
      JSON.stringify(this.patientArr);
      console.log(this.patientArr);
      this.dataSource = new MatTableDataSource(this.patientArr);
      // this.dataSource.paginator = this.paginator;
      return this.patientArr;
    });
  }

  go(){
    
  }

  getUsers() {
    this.service.getUser().subscribe(res => {
      this.userArr = res;
      JSON.stringify(this.userArr);
      console.log(this.userArr);
      this.dataSource1 = new MatTableDataSource(this.userArr);
      console.log(this.dataSource1);
    });
  }
  notifButtonClick(bloodgroup: string, patient: Patient) {
    this.sendRequestToUser(patient)
    console.log(bloodgroup)
    if (bloodgroup === 'A-') {
      if (this.Aminus > 0) {
        alert("Blood Group Matched")
        this.Aminus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'B+') {
      if (this.Bplus > 0) {
        alert("Blood Group Matched")
        this.Bplus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'A+') {
      if (this.Aplus > 0) {
        alert("Blood Group Matched")
        this.Aplus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'AB+') {
      if (this.ABplus > 0) {
        alert("Blood Group Matched")
        this.ABplus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'AB-') {
      if (this.ABminus > 0) {
        alert("Blood Group Matched")
        this.ABminus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'A+') {
      if (this.Aplus > 0) {
        alert("Blood Group Matched")
        this.Aplus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'B-') {
      if (this.Bminus > 0) {
        alert("Blood Group Matched")
        this.Bminus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'O+') {
      if (this.Oplus > 0) {
        alert("Blood Group Matched")
        this.Oplus--
      }
      else
        alert("Blood Group Not Matched")
    }
    else if (bloodgroup === 'O-') {
      if (this.Ominus > 0) {
        alert("Blood Group Matched")
        this.Ominus--
      }
      else
        alert("Blood Group Not Matched")



    }



  }

  sendNotification() {
    for (const p of this.patientArr) {
      for (const u of this.userArr) {
        if (p.patientBloodGroup === u.userBloodGroup) {
          alert('Blood Group Matched');
          this.count === 1;
          break;
        }
      }
      if (this.count === 0) {
        alert('This blood group is not avaliable');
        this.count = 0;
      }
    }


  }

  sendRequestToUser(patient) {
    this.service.sendRequestToUser(patient).subscribe(

    )
  }

  deletePatients(patient: Patient): void {
    this.service.deletePatients(patient.id)
      .subscribe(data => {
        this.patient = this.patient.filter(u => u !== patient);
      })
  }


  deleteUser(user: User): void {
    this.service.deleteUser(user.id)
      .subscribe(data => {
        this.user = this.user.filter(a => a !== user);
      })
  }
  
  searchPatient : Patient
   getPatientById(event : number, patient:Patient) {
    
     console.log(event)
     
     
     this.service.searchPatientById(event)
     .subscribe(data => {
        this.patient = data

     })
     
   }
  

   searchUser : User
   getUserById(event : number, user:User) {
    
     console.log(event)
     
     
     this.service.searchPatientById(event)
     .subscribe(data => {
        this.patient = data

     })
     
   }

  logout() {

    sessionStorage.removeItem('password');
    sessionStorage.removeItem('adminEmailId');
    sessionStorage.setItem("isLoggedIn", 'false');
    this.router.navigate(['/login']);


  }
array: any;
//   matchUser(bloodgroup: string, location: string) {
//     this.service.matchUser(bloodgroup, location).subscribe(

//       res => {

//         if (res.length === 0) {

//           alert("No user with matching bloodgroup and location found")
//         }

//         this.matcheduserArray = res
// this.array = this.matcheduserArray
//       }
//     );
//   }


  //   selectUser(id: number) {
  //   this.service.selectUser(id).subscribe(
  //     res => {
  //       console.log(res)
  //     }
  //   );
    
  // }
  doFilter = (value: string) => {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
  
  }
  doFilterUser = (value: string) => {
    this.dataSource1.filter = value.trim().toLocaleLowerCase();
  
  }
  matchUser(patient: Patient) {
    console.log(patient)
    console.log(patient.patientHospitalLoc)
    console.log(patient.patientBloodGroup)
    this.service.matchUser(patient.patientBloodGroup, patient.patientHospitalLoc).subscribe(
      
      res => {

        if (res.length === 0) {

          alert("No user with matching bloodgroup and location found")
        }

        this.matcheduserArray = res
        this.array = this.matcheduserArray;
        this.dataSource2 = new MatTableDataSource(this.array);
        console.log(this.matcheduserArray)
        this.matcheduserArray.forEach(p =>{
          this.sendNotifToUser(patient,p.id)
        })
       
      }
    );

    


  
  }

  sendNotifToUser(patient:Patient,id:number){
  
      this.service.sendNotifToUser(patient,id).subscribe(
        res =>{
          console.log(res)
        }
      );

    

  }


}








