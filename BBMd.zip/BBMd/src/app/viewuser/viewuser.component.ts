import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { User } from '../model/user';
import { Patient } from '../model/patientdetails';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewuser',
  templateUrl: './viewuser.component.html',
  styleUrls: ['./viewuser.component.css']
})
export class ViewuserComponent implements OnInit {


  userArr: User[] = [];
  user: User;
  patient: Patient;
  patientArr : Patient[];
  constructor(private service: ServiceService, private router: Router) {
  }

  ngOnInit() {
   
    this.service.getUserByEmail(sessionStorage.getItem('useremail')).subscribe(res => {
      this.user = res;
    });
  }

  getUserByEmail() {
    this.service.getUserByEmail(sessionStorage.getItem('useremail')).subscribe(res => {
      this.user = res;
      this.patientArr = res.matchedpatients
      console.log(this.patientArr)
      JSON.stringify(this.user);
      console.log(this.user);
    });
  }

  
    selectUser() {
    alert("Thank you for donating blood...!")
    this.service.selectUser(sessionStorage.getItem('useremail')).subscribe(
      res => {
        console.log(res)
      }
    );
  }

  deletePatients(patient: Patient) {
    this.service.deletePatients(patient.id)
      .subscribe(data => {
        this.patient = this.patient.filter(u => u !== patient);
      });
  }
  logout() {
    sessionStorage.removeItem('useremail');
    this.router.navigate(['/userlogin']);
  }
}
