import { Component, OnInit } from '@angular/core';
import { UserLogin } from '../model/userlogin';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { User } from '../model/user';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  userlogin: User;

  constructor(private service: ServiceService, private router: Router) {
    this.userlogin = new User();
  }

  ngOnInit() {
    window.location.hash = "no-back-buton";
    window.location.hash = "Again-No-back-buton";
    window.onhashchange = function () {
      window.location.hash = "no-back-buton";
    }
  }

  
  getLogin() {

    this.service.verifyUser(this.userlogin).subscribe(res => {
      console.log(this.userlogin)
      this.userlogin = res;
      if (this.userlogin != null) {
        sessionStorage.setItem('useremail', this.userlogin.userEmail);
        alert('Login Successful')
        this.router.navigate(['viewuser'])
        console.log(this.userlogin)
      }
      else
      {
        alert('Invalid credential')
      }
    }
    );


  };
}
