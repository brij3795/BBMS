import { Patient } from './patientdetails';

export class User {
  filter(arg0: (u: any) => boolean): User {
    throw new Error("Method not implemented.");
  }
 id: number;
 userFirstName: any;
 userLastName: any;
 userContact: any;
 userEmail: any;
 userBloodGroup: any;
 uDOB:Date;
 userAddress:any;
 userGender:any;
 userPassword:any;
 matchedpatients : Patient[];

}
